 //@Author Hilda Fleming 
 //Student Identification number: 18476813
//Pledge: I pledge by honor  that this is solely my own work.
/*Description: Creates a fx game that generates random black numbers with a red dot that you control
 *  to eat the black dots it has a counter built in that counts the remainder of black dots as well
 *   as a timer*/

package Application;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			StackPane root = new StackPane(); //Import the first option for StackPane

			double width = 400, height = 400;
			int radius = 10, speed = 5;

			Pane gamePane = new Pane(); //Import first option for Pane package
			root.getChildren().add(gamePane);

//Creates the timer
			VBox timerBox = new VBox();
			timerBox.setAlignment(Pos.TOP_CENTER);
			root.getChildren().add(timerBox);

			Label elapsed = new Label("0"); //This makes the timer start at zero
			elapsed.setFont(Font.font(20)); //sets the font to the size of 20
			elapsed.setTextFill(Color.BLUE); //sets the color to blue
			timerBox.getChildren().add(elapsed); //adds it to the pane


//Creates the target left
			VBox labelLeft = new VBox(); //Creates the pane
			labelLeft.setAlignment(Pos.BOTTOM_CENTER); //positions the counter at the bottom of the screen
			root.getChildren().add(labelLeft);  //adds the counter to the pane

			Label label = new Label(); //Creates the target label
			label.setFont(Font.font(20)); //sets the font to the size of 20
			label.setTextFill(Color.GREEN); //sets the color to green
			labelLeft.getChildren().add(label); //Adds the clock to the pane








			Circle movingc = new Circle(height/2, width/2, radius); //sets the circle at the center of the game pane with the radius variable
			movingc.setFill(Color.RED); //Sets the circle colour
			gamePane.getChildren().add(movingc);//adds it to the center of the game pane


			//Creating black circles spanning at random....
			double randomx; //generating the random x of the circle
			double randomy; //generating the random xy of the circle
			int randoma = ThreadLocalRandom.current().nextInt(5,10); //Will generate a random number between 5 and 10 to spawn circles
			int amount = 1; //Sets the amount of circles to start at 1
			while(amount < randoma) { //The while loop is used to keep the loop looping while the amount is less than the random number generated
				randomx = ThreadLocalRandom.current().nextDouble(5, width-5); //The radius is 5 pixels, and then generates the random x
				randomy = ThreadLocalRandom.current().nextDouble(5, height-5);//The radius is 5 pixels, and then generates the random y
				Circle dot1 = new Circle(randomx, randomy, 5); //This will generate the black circles with the randomx and randomy coordinates. It sets the speed at 5
				dot1.setFill(Color.BLACK); //sets the dots generated to colour black
				gamePane.getChildren().add(dot1); //adds the dots to the game pane
				amount++; //Increments the amount of dots until it becomes false
			}
			gamePane.setFocusTraversable(true); //contineuasly recieve the focus from the user input from the keyboard pressing arrow keys


			Scene scene = new Scene(root,width,height);
			primaryStage.setScene(scene);
			primaryStage.show();

			gamePane.requestFocus();//bring the game pane to focus

			AnimationTimer timer = new AnimationTimer() { //uses the animation timer class to create timer
				private long startTime = System.currentTimeMillis(); //sets a new variable to set the time
				@Override public void handle(long stamp) { //This creates a override to override this class method
					long present = System.currentTimeMillis(); 
					double elapseTime = (present - startTime)/1000.0;
					elapsed.setText("Elapsed Time: "+(int)elapseTime + " seconds"); //This sets the time and it converts this to a string to a label in order to be displayed

				}
			};
			timer.start(); //calls the timer input 

			gamePane.setOnKeyPressed(e -> { //Assigns the arrow keys
				double x = movingc.getCenterX(); //gets the current position of the dots by using the x and y cooridinates
				double y = movingc.getCenterY();

				switch(e.getCode()) { //Each of the arrow keys are represented by a code which is an integer
				case UP: //Creates the static values
					if (y > radius) //if it hasnt reached the top edge (Makes sure that it doesnt move out of the scope of the pane)
						movingc.setCenterY(y - speed); //Sets the circle in a new position
					break;
				case LEFT:
					if(x > radius) //if it hasnt reached the far left edge (Makes sure that it doesnt move out of the scope of the pane)
						movingc.setCenterX(x - speed);
					break;
				case DOWN:
					if(y < height - radius)
						movingc.setCenterY(y + speed);
					break;
				case RIGHT:
					if(x < width - radius)
						movingc.setCenterX(x + speed);
				default: //nothing to do
					break;
				}

				//to collect all overlapping black dots
				List<Node> overlaps = new LinkedList<>();
				ObservableList<Node> allCircles = gamePane.getChildren();
				for(Node n : allCircles) {
					Circle c = (Circle) n;
					if(isOverlap(movingc, c)) { //checks to see if the circle is overlapping with the moving c
						overlaps.add(c);
					}

				}
				for(Node n : overlaps) {
					allCircles.remove(n); //This removes the overlapping circles
					label.setText("Target Left" + ((int) allCircles.size() -1)); //displays the label and how many of the dots are left to go
				}

				if(allCircles.size() == 1) {
					movingc.setFill(Color.BLUE);
					//Only the red circle is left on panel
					timer.stop();
				}

			});
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public boolean isOverlap(Circle c1, Circle c2) { //This method takes 2 circles
		double x1 = c1.getCenterX();
		double y1 = c1.getCenterY();
		double x2 = c2.getCenterX();
		double y2 = c2.getCenterY();

		double comp1 = Math.pow(Math.abs(x2 - x1), 2);
		double comp2 = Math.pow(Math.abs(y2 - y1), 2);
		double distance = Math.sqrt(comp1 + comp2);
		double r1 = c1.getRadius();
		double r2 = c2.getRadius();
		boolean cond1 = distance <= r1 + r2;
		boolean cond2 = distance > 0; //This condition  is added to eliminate the red circle being compared to itself
		boolean overlap = cond1 && cond2;
		return overlap;

	}
	public static void main(String[] args) {
		launch(args);
	}
}