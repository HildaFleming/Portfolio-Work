package q2_assignment2;

public class Card {
	//creates private class field called suit
	private String suit;

	//Declaring public methods you use to access the private fuse object
	public String getSuit() { //getter method with no parameter
		return suit; //returns private fuse object suit
	}


	public void setSuit(String suit) {  //Setter method which require a parameter of suit
		this.suit = suit; /*When setter method is called the new suit is provided
		the new suit is then set to the */
	}
	
	
	//creates private class field called faceValue
	private int faceValue; 


	public int getFaceValue() {//Creates a method called getFaceValue with no parameters set 
		return faceValue; //returns facevalue
	}


	public void setFaceValue(int faceValue) { //Creates void method called getFaceValue with int face value parameters 
		this.faceValue = faceValue; //Sets the faceValue of Card to equal the faceValue parameter
	}

	public void  displayCard() { //Creates void method called displayCard with no parameters
		System.out.printf("The card is: %s", this.getSuit(), this.getFaceValue());	// �The card is <suit> <faceValue>�).
	}

	public Card(String suit, int faceValue) { //Creates a public method Card with parameters suit and faceValue
		//This will give the state of the two classes
		this.setFaceValue(faceValue);   //Sets the faceValue of Card to equal the faceValue parameter 
		this.setSuit(suit);  //Sets the setSuit of Card to equal the suit parameter
	}
}