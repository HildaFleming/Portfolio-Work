package q3_assignment3;

public class Box extends Container {  //Creates a class called Box which inherits information from Container class


	//Getters and setters generated for Box class
	private double length; //Creates private field for length

	public double getLength() { //Creates a method called getLenth with no parameters set 
		return length; //with a return value
	}
	public void setLength(double length) { //Creates a method called setLength with length parameter set 
		this.length = length; //When setter method is called the new length is provided
	}
	private double height; //Creates private field for height

	public double getHeight() { //Creates a method called getHeight with no parameters set 
		return height; //Which returns the height 
	}
	public void setHeight(double height) { //Creates a method called setHeight with height parameter set 
		this.height = height; //When setter method is called the new height is provided
	}
	private double width; //Creates private field for width

	public double getWidth() {  //Creates a method called getWidth with no parameters set
		return width; //Which returns the width 
	}
	public void setWidth(double width) { //Creates a method called setWidth with width parameter set 
		this.width = width; //When setter method is called the new width is provided
	}//End of Getter and setter generator

	public Box(String Colour, double length, double height, double width) { /*Creates a public method called Box with parameters
	Colour, length, height and width*/
		super(Colour); //calls the super class of colour

		this.setHeight(height);  //Sets the setHeight of Box to equal the height parameter
		this.setLength(length);  //Sets the setLength of Card to equal the length parameter
		this.setWidth(width);   //Sets the setWidth of Card to equal the width parameter
		// TODO Auto-generated constructor stub
	}
	public String getContainerType() {//Creates a method called getContainerType with no parameters set 
		return "Im a Box"; //Which returns a string 
	}

	public double getVolume() { //Creates a method called getVolume with no parameters set 
		return height*length*width; //That returns the sum of height, length and width
	}
}