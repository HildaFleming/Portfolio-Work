package q3_assignment3;

public class Container { //Creates a class called container

	private String Colour; //Creates private field for Colour

	public String getColour() { //Creates Getter for Colour
		return Colour;  //With a return value of Colour
	}

	public void setColour(String colour) { //Creates Setter for Colour
		Colour = colour; //When setter method is called the new colour is provided
	}

	public Container(String Colour) { //Creates a constructor for container with a set parameter colour
		this.Colour = Colour;  //Sets the Colour of container to equal the Colour parameter
	}

	//private String ContainerType; //creates a private field for ContainerType
	
	public String getContainerType() {	//Creates a method called ContainerType with a string datatype
		return "I am a Container"; //With a return value 
	}
}