 //@Author Hilda Fleming 
 //Student Identification number: 18476813
//Pledge: I pledge by honor  that this is solely my own work.
/*Description: This Program creates two parameters for a container and box.Creates private 
 * fields with getters and setters. Arrays are used to ouput the overlapping colours and volumes between the
 * boxes*/
package q3_assignment3;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		List<Container> containers = new LinkedList<>();
		containers.add(new Container("red"));
		containers.add(new Box("white", 4, 3, 2));
		containers.add(new Box("black", 5, 13, 8));
		containers.add(new Container("orange"));
		displayContainerTypes(containers); //produces output part 1
		Box[] boxArray1 = {
				new Box("white", 4, 3, 2),
				new Box("red", 9, 5, 6),
				new Box("purple", 3, 6, 12),
				new Box("orange", 15, 10, 4),
				new Box("black", 4, 14, 10),
		};
		Box[] boxArray2 = {
				new Box("pink", 3, 4, 2),
				new Box("red", 10, 2, 4),
				new Box("white", 8, 5, 7),
				new Box("blue", 14, 4, 10),
				new Box("bindle", 10, 15, 4),
		};

		//produces output part 2
		countOverlapBoxes(boxArray1, boxArray2);
	}
	public static void displayContainerTypes(List<Container> containers){
		//Complete method to produce the sample run output below (part 1)
		//Hint: iterate list �containers�, invoke getContainerType() on each instance

		for (Container i : containers) {//itterates through the cards array
			System.out.println(i.getContainerType());
		}//returns the string describing container type
	}

	public static void countOverlapBoxes(Box[] group1, Box[] group2){
		// Complete method to produce the sample run output below (part 2)
		// Note: you can assume that the colours in each group are unique,
		// i.e., there are no duplicate colours within each group. 
		int count1 = 0; //sets counter 1 and 2 to equal 0
		int count2 = 0;
		for (Box d1 : group1) { //d1 is equal to the outer array and takes the current element of the array
			for (Box d2 : group2) { //d2 is equal to the inner array and takes the current element of the array

				if (d1.getColour().equalsIgnoreCase(d2.getColour())) { //Checks if the values are matching and compares 1 element from d1 to all the elements in d2
					count1 ++; //Increments count1
				}
				if (d1.getVolume() == (d2.getVolume())) { //Checks if the values are matching compares 1 element from d1 with all the elements in d2
					count2 ++; //Increments count2
				}
			}
		}
		//Ouputs these two lines with placeholder values for the counters
		System.out.printf("There are %d box objects with overlapping colour between the two arrays\n", count1); 
		System.out.printf("There are %d box objects with overlapping volume between the two arrays\n", count2);
	}
}