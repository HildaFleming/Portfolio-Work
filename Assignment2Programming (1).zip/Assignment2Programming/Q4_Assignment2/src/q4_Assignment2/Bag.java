package q4_Assignment2;

public class Bag {

	private String colour; //Creates a private method colour

	public String getColour() { //getter method with no parameter
		return colour; //Which returns colour
	}

	public void setColour(String colour) {   //Setter method which require a parameter of colour
		this.colour = colour; //Sets the colour of Bag to equal the colour parameter
	}
	
	private double volume; //Creates a private method volume
 
	public double getVolume() { //getter method with no parameter
		return volume; //which returns volume
	}

	public void setVolume(double volume) { //Setter method which require a parameter of volume
		this.volume = volume; //Sets the volume of Bag to equal the volume parameter
	}

	public Bag(String colour, double volume) { //Creates a public method called bag with parameters colour and volume
		this.setColour(colour); //And sets the colour to equal the colour parameter
		this.setVolume(volume);  //And sets the volume to equal the volume parameter
	}
}