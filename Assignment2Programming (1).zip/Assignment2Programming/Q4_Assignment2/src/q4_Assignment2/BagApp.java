package q4_Assignment2;

import java.util.List;

public class BagApp {
	public double calcTotalVolume(List<Bag> bagList, double accum) {
		//Write the code for this recursive method
		//This calculates and returns the total volume of all instances in �bagList�.
		
		//Creates the base case
		if(bagList != null && bagList.size() > 0) {
			List<Bag> sub = bagList.subList(1, bagList.size());
			accum += bagList.get(0).getVolume(); //adds the first element to the accumulator



			return calcTotalVolume(sub, accum);
		} else {

			return accum;
		
		
			//End of class BagApp
		}
	}
}