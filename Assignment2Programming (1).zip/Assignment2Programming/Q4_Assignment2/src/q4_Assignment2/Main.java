 //@Author Hilda Fleming 
 //Student Identification number: 18476813
//Pledge: I pledge by honor  that this is solely my own work.
/*Description: This creates a recursion of a list of objects. 
 * It then ouputs the total amount of bags and volume*/
package q4_Assignment2;

import java.util.LinkedList;
import java.util.List;

public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Bag> bags = new LinkedList<>();
		 //fill in code here: create a list of Bag instances
		 //and add to the list �bags�.
		
		
		//The bag instances added to the list bags
		bags.add(new Bag("red", 2));
		 bags.add(new Bag("white", 4));
		 bags.add(new Bag("black", 5));
		 bags.add(new Bag("orange", 9));
		 BagApp bgapp = new BagApp(); //Calls on the bag class with the recursive method inside it
		 double totalVolume = bgapp.calcTotalVolume(bags, 0);
		 System.out.printf("Total number of bags: %d\n", bags.size()); //outputs the total number of bags
		 System.out.printf("Total volume: %.2f\n", totalVolume); //outprints the total volume
		 }
		 }//End of class Main

