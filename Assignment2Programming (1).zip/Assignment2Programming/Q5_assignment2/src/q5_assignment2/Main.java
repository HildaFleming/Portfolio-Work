 //@Author Hilda Fleming 
 //Student Identification number: 18476813
//Pledge: I pledge by honor  that this is solely my own work.
/*Description: Creates a txt file with input and you creates methods to call that data from the txt file.
 * It then outputs the data from the txt such as the score and the ID in a tabular format. It also displays
 * things like the lowest score, top student ID, the range of scores between 50 and 80 and the total of scores.*/
package q5_assignment2;

import java.io.IOException;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		String txtfile = "datafolder/data.txt"; //the file name and its pathway
		try { //closes the code with try instead of adding an exception
			ScoreApp scoreapp = new ScoreApp(txtfile); //creating scoreApp object and then passing the constructor filename
			scoreapp.printAll();
			System.out.println();
			System.out.printf("Lowest score: %.2f\n", scoreapp.getMinScore());
			System.out.printf("Top student ID: %s\n", scoreapp.getTopStudentID());
			System.out.printf("Scores between 50-80: %d\n", scoreapp.countScoreRange());
			double total = recursiveTotalScore(scoreapp.getStudents(), 0);
			System.out.printf("Total scores: %.2f\n", total);
		}catch(IOException ioe) {
			System.out.printf("Perhaps missing text file: %s/%s? \n\n",
					new Main().getClass().getPackage().getName(), txtfile);
		}
	}//End of main method
	public static double recursiveTotalScore(List<student> list, double accum) {
		if(list != null && list.size() > 0) {
			accum += list.get(0).getScore();
			List <student>subList = list.subList(1, list.size());
			return recursiveTotalScore(subList, accum);
		}else {
			return accum;
		}
		// write the code
	}
}//End of class Main