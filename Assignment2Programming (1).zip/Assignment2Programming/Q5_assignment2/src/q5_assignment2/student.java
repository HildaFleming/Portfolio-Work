package q5_assignment2;

public class student {//Creates a class called student
	private String ID; /*Creates 2 private class fields one as a string called ID
 and the other as a double called score*/
	private double score;	

	//Creates the getter method to class field ID
	public String getID() { //Creates a getter for ID
		return ID; //And returns ID
	}
	//Creates the setter method to class field ID
	public void setID(String iD) {  //Creates a set method or a setter with a parameter of iD
		ID = iD; //Says that ID from student is equal to ID
	}

	public double getScore() { //Creates a getter for score
		return score; //And returns score
	}
	public void setScore(double score) { //Creates a set method or a setter with a parameter of score
		this.score = score; //Says that score from student is equal to score
	}


	public student( String ID, double score) { /*Creates a constructor called student
	which takes the parameters ID and grade*/ 
		this.ID = ID; //Then use this parameter ID to set the class field to equal to ID parameter
		this.score = score; //Then use this parameter grade to set the class field to equal to grade parameter

	}
	public void displayStudent() {
		System.out.printf("%-10s%-20f%, id", this.getID()); //Outputs it to the screen with the a set format from the getID getter
		System.out.printf("%-10s%-20f%, id", this.getScore()); //Outputs it to the screen with the a set format from the getscore getter
	}

}