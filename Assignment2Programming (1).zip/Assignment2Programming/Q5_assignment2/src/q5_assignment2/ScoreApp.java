package q5_assignment2;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

public class ScoreApp { //Creates a public class called ScoreApp
	private List<student> students; /*creates a private field list called 
	students with a data type of student*/
	public List<student> getStudents() {
		// TODO Auto-generated method stub
		return students;
	}
	//Creates list of student objects as the field

	//creates a constructor called ScoreApp constructor and takes a paramater which is the filename
	public ScoreApp(String filename) throws IOException{ //the fn stands for filename
		students = new LinkedList<>();//Within the constructor you inistualse the students list
		readData(filename);/*Then you need to read student data and then pass the filename to the method readStudentData 
		(When you throw the exception on the line below you either need to handle the IO exception in this line or throw it to the caller)*/
	}

	public void readData(String filename) throws IOException{ /*Writes readStudentData method 
	(here you need to throw an exception because reading a file is a check exception it gets thrown to the caller)*/
		Path path = new File(filename).toPath();//then you get the path information from the filename
		List<String> content = Files.readAllLines(path);/*Then you read the list read the file content as a list of strings and then call the list of strings content*/

		for (String line : content) {//Becuase the content is a list you will use a for each loop to get each line from the content 
			String[] items = line.split(",");//Then you split each line into an array of strings (the delimeter character is the comma from the data.txt file)
			student s = new student(items[0],Double.parseDouble( items[1]));//Then you create a student object 
			students.add(s);//And you add each student object to the students list
		}
	}


	public void printAll() {
		//To display the objects in the list you use a for loop to iterate through the list of student objects and each object in students list is then in student object
		for (student s : students) { //loops used to itterate the list of student objects
			//creates a variable called student and s which is used to represent each element in the list (it says for each student object in the students list)
			System.out.printf("%20s%10.2f\n", s.getID(), s.getScore()); //you want to output the items
		}
	}


	public double getMinScore() {
		student minScore = students.get(0);//candidate
		for (student s : students) { //compares each student with the scores
			if (s.getScore() < minScore.getScore()) {
				minScore = s;//sync flag variable
			}
		}
		return minScore.getScore(); 
	}


	public int countScoreRange() {
		// write the code
		int count = 0;
		for (student s : students) {
			if (s.getScore() >= 50 && s.getScore() <= 80) { //The && is used to join the overlapping scopes
				count = count + 1;			}

		}
		return count;

	}

	public String getTopStudentID() {
		// write the code
		student maxScore = students.get(0);//candidate
		for (student s : students) { //compares each student with the scores
			//compare each student id with score
			if (s.getScore() > maxScore.getScore()) {
				maxScore = s;//sync flag variable
			}
		}
		return maxScore.getID(); 
	}
}//End of class ScoreApp
